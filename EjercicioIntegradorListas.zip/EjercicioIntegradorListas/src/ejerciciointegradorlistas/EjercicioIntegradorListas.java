package ejerciciointegradorlistas;


public class EjercicioIntegradorListas {

  
    public static void main(String[] args) 
    {
       Empresa empresa= new Empresa();
       cargarEmpresa(empresa);
       
       empresa.listarDispositivos();
//       for(Dispositivo d:empresa.listarDispositivosPorTipo(Tipo.TABLET) )
//       {
//        System.out.println(d);
//       }
//       for(Dispositivo d:empresa.listarDispositivosPorTipo(Tipo.TELEFONO) )
//       {
//        System.out.println(d);
//       } 
//       for(Dispositivo d:empresa.listarDispositivosPorTipo(Tipo.COMPUTADORA) )
//       {
//        System.out.println(d);
//       }
//       
       System.out.println("--------------lista final---------------------");
       System.out.println(empresa.borrarDispositivo("KS293")); //TABLET suc_2
//       System.out.println(empresa.borrarDispositivo("JH286")); //TABLET suc_2
//       System.out.println(empresa.borrarDispositivo("DF345")); //TABLET suc_2
       System.out.println(empresa.borrarDispositivo("AA111")); //NO EXISTE
       System.out.println(empresa.borrarDispositivo("AS323"));//COMPUTADORA suc_1
       System.out.println("---------------FIN LISTA FINAL--------------------");
       empresa.listarDispositivos();
       
       double[] porcentaje= new double[Tipo.values().length];
       porcentaje= empresa.porcentajeDispositivosPorTipo("Sucursal A");
       int i;
       for(i=0;i<porcentaje.length;i++)
       {
       System.out.printf("%.2f \n",porcentaje[i]);
       }
        
       
    }
    public static void cargarEmpresa(Empresa empresa)
    {
       
       Sucursal suc_1 = new Sucursal("Sucursal A");
       Sucursal suc_2 = new Sucursal("Sucursal B");
       
       suc_1.agregarDispositivo(new Dispositivo("AA123",12400,Tipo.COMPUTADORA));
       suc_1.agregarDispositivo(new Dispositivo("BX320",15400,Tipo.TABLET));
       suc_1.agregarDispositivo(new Dispositivo("AS323",18300,Tipo.COMPUTADORA));
       suc_1.agregarDispositivo(new Dispositivo("AJ119",12500,Tipo.TELEFONO));
       
       suc_2.agregarDispositivo(new Dispositivo("KS293",17800,Tipo.TABLET));
       suc_2.agregarDispositivo(new Dispositivo("JH286",13400,Tipo.TABLET));
       suc_2.agregarDispositivo(new Dispositivo("DF345",19300,Tipo.TELEFONO));
       
       empresa.agregarSucursal(suc_1);
       empresa.agregarSucursal(suc_2); 
       
       
    }
    
}
