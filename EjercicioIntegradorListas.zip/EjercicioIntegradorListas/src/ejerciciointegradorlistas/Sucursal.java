
package ejerciciointegradorlistas;

import java.util.ArrayList;


public class Sucursal 
{
    private String nombre;
    private ArrayList<Dispositivo> dispositivos; 

    public String getNombre()
    {
        return this.nombre;
    }
    
    
    public Sucursal(String nombre) 
    {
        this.nombre = nombre;
        this.dispositivos = new ArrayList<Dispositivo>();
    }
    
    public void agregarDispositivo(Dispositivo dispositivo)
    {
       if(dispositivo!=null)
       {
         this.dispositivos.add(dispositivo);
       }
    }
    
    public void listarDispositivo()
    {
        if(dispositivos.isEmpty())
        {
            System.out.println("No hay dispositivos"); 
        }
        else
        {
            for(Dispositivo d: dispositivos)
            {
                if(d!=null)
                {
                    System.out.println(d);
                }
            }
        }   
    }
    
    public ArrayList<Dispositivo> listarDispositivosPorTipo(Tipo tipoDeDispositivo)
    {
        ArrayList listaRetorno= new ArrayList<>();
        
       if(dispositivos.isEmpty())
        {
            System.out.println("No hay dispositivos"); 
        }
        else
        {
            for(Dispositivo d: dispositivos)
            {
                if(d!=null &&(d.getTipo()==tipoDeDispositivo))
                {
                   listaRetorno.add(d);
                }
            }
        }
       return listaRetorno;
    }
    public Dispositivo buscarDispositivo(String id)
    {
        
        return (this.estaDispositivo(id)? this.dispositivos.get(this.buscarIndiceDispositivo(id)): null);
    }
    
    public boolean estaDispositivo(String id)
    {
        return this.buscarIndiceDispositivo(id)!= -1;
    }
    
    
    private int buscarIndiceDispositivo(String id)
    {
//        int i;
//        for(i=0;i<this.dispositivos.size();i++)
//        {
//            if(this.dispositivos.get(i)!=null &&(this.dispositivos.get(i).getID()== id))
//                {
//                   return i;
//                }
//        }
        //OPCION MEJORADA
        
        int i=0;
        while((i<this.dispositivos.size())&& !(this.dispositivos.get(i).getID().equals(id)))
        {
            i++;
        }
         
        return  (i==this.dispositivos.size() ? -1:i);
    }
    
    public Dispositivo borrarDispositivo(String id)
    {
        Dispositivo borrado=null;
//        try
//        {
//        return (this.dispositivos.remove(this.buscarIndiceDispositivo(id)));
//        }
//        catch(Exception ex)
//        {
//           borrado=null; 
//        }  
//        return borrado;
        
        if(this.estaDispositivo(id))
        {
            borrado= this.dispositivos.remove(this.buscarIndiceDispositivo(id));           
        }
        return borrado;    
    }
    public double[] porcentajeDispositivosPorTipo()
    {
        double porcentajes[]= new double[Tipo.values().length];
        
       if(dispositivos.isEmpty())
        {
            System.out.println("No hay dispositivos"); 
        }
        else
        {
            for(Dispositivo d: dispositivos)
            {
                if(d!=null)
                {
                   porcentajes[d.getTipo().ordinal()]+=1;
                }
            }
        }
       
        for(int i=0;i<porcentajes.length;i++)
        {  
           porcentajes[i]=(porcentajes[i]*100)/porcentajes.length;   
        }
        
       return porcentajes;
    }
}
