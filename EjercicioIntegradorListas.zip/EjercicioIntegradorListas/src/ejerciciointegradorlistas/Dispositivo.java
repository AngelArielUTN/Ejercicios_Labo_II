
package ejerciciointegradorlistas;


public class Dispositivo {
  private final String  ID;
  private double precio;
  private Tipo tipoDeDispositivo;

    public Dispositivo(String ID, double precio, Tipo tipoDeDispositivo)
    {
        this.ID = ID;
        this.precio = precio;
        this.tipoDeDispositivo = tipoDeDispositivo;
    }

    public String getID()
    {
        return this.ID;
    }
    
    public Tipo getTipo()
    {
        return tipoDeDispositivo;
    }
    @Override
    public String toString() 
    {
        return "Dispositivo{" + "ID=" + ID + ", precio=" + precio + ", tipoDeDispositivo=" + tipoDeDispositivo + '}';
    }
  
}
