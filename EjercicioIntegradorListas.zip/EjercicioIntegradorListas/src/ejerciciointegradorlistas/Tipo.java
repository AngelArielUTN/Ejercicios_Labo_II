
package ejerciciointegradorlistas;


public enum Tipo {
   TELEFONO,
   COMPUTADORA,
   TABLET;
   
   @Override
   public String toString()
   {
       String cadena=super.toString();
       return cadena.substring(0, 1)+ cadena.substring(1).toLowerCase();
   }
}
