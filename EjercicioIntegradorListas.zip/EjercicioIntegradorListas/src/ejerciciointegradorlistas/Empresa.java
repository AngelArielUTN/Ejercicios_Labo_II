
package ejerciciointegradorlistas;

import java.util.ArrayList;


public class Empresa {
  
   private ArrayList<Sucursal> sucursales; 

    public Empresa() 
    {
        this.sucursales = new ArrayList<Sucursal>();
    }
   
    public void agregarSucursal(Sucursal sucursal)
    {
        if(sucursal!=null)
        {
            this.sucursales.add(sucursal);
        }
    }
    public void listarDispositivos()
    {
        if(sucursales.isEmpty())
        {
            System.out.println("No hay dispositivos"); 
        }
        else
        {
            for(Sucursal s: sucursales)
            {
                if(s!=null)
                {
                    //System.out.println(s);
                    s.listarDispositivo();
                    System.out.println("----------------------");
                }
            }
        }
    }
    
    public ArrayList<Dispositivo> listarDispositivosPorTipo(Tipo tipoDeDispositivo)
    {
        ArrayList listaRetorno= new ArrayList<>();
        
        if(sucursales.isEmpty())
        {
            System.out.println("No hay dispositivos"); 
        }
        else
        {
            for(Sucursal s: sucursales)
            {
                if(s!=null)
                {
                   
                    listaRetorno.addAll(s.listarDispositivosPorTipo(tipoDeDispositivo));
                    System.out.println("----------------------");
                }
            }
        }
        return listaRetorno;
    }
    
    public Dispositivo borrarDispositivo(String id)
    {
        Dispositivo borrado=null;
        int i=0;
        while(i<this.sucursales.size() && (borrado==null))
        {
           borrado= this.sucursales.get(i).borrarDispositivo(id);
           if(borrado==null)
           {
                i++;
           } 
        }
      
        return (i>this.sucursales.size() ? null : borrado);  
    }
    
    private Sucursal sucursalPorNombre(String nombre)
    {
        int i=0;
        
        while(i<this.sucursales.size() && !(sucursales.get(i).getNombre().equals(nombre)))
        {
           i++;
        }
        return (i>this.sucursales.size() ? null :sucursales.get(i) ); 
    }
    
    public double[] porcentajeDispositivosPorTipo(String nombreSucursal)
    {
//        double porcentajes[]= new double[Tipo.values().length];
//        
//        Sucursal sucursal=null;
//        int i=0;
//        while(i<this.sucursales.size() && (sucursal==null))
//        {
//           if(sucursales.get(i).getNombre().equals(nombreSucursal))
//           {
//             sucursal= this.sucursales.get(i);
//             porcentajes =sucursal.porcentajeDispositivosPorTipo();
//           } 
//           i++;
//        }
//        
//        return (i>this.sucursales.size() ? null : porcentajes);  
        Sucursal sucursal= this.sucursalPorNombre(nombreSucursal);
        if(sucursal == null)
        {
            return null;
        }
        return sucursal.porcentajeDispositivosPorTipo(); 
    }
}
